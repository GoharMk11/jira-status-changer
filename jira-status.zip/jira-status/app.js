const tabId = Number(new URLSearchParams(location.search).get('tab'));
const byId = (id) => document.getElementById(id);
const keys = byId('keys');
const inspect = byId('inspect');
const target = byId('target');
const apply = byId('apply');
const message = byId('message');
let context;
let issues = [];
let busy = true;
let previewReady = false;

// Chrome serializes this function and runs it in the original Jira tab.
async function jira(operation, input) {
  try {
    const origin = location.origin;
    const path = location.pathname;
    const contextPath = path.match(/^(.*?)\/(?:browse|secure)\//)?.[1] ?? '';
    const url = new URL(location.href);
    const issueKey = [
      path.match(/\/browse\/([^/]+)/)?.[1],
      url.searchParams.get('selectedIssue'),
      url.searchParams.get('issueKey')
    ].find((value) => /^[A-Z][A-Z0-9_]*-\d+$/i.test(value ?? ''));
    const project = issueKey?.split('-')[0].toUpperCase() ??
      path.match(/\/projects\/([A-Z][A-Z0-9_]*)(?:\/|$)/i)?.[1]?.toUpperCase();

    async function request(route, options) {
      const response = await fetch(contextPath + '/rest/api/2/' + route, {
        ...options,
        mode: 'same-origin',
        credentials: 'same-origin',
        signal: AbortSignal.timeout(20000),
        headers: { Accept: 'application/json', 'Content-Type': 'application/json' }
      });
      if (!response.ok) {
        const payload = await response.json().catch(() => ({}));
        const details = [...(payload.errorMessages ?? []), ...Object.values(payload.errors ?? {})];
        throw new Error(details.length ? `HTTP ${response.status} · ${details.join(' · ')}` : `HTTP ${response.status}`);
      }
      if (response.status === 204) return;
      if (!response.headers.get('content-type')?.includes('application/json')) {
        throw new Error('Jira API-ն JSON պատասխան չվերադարձրեց։ Ստուգիր մուտքը և բացված էջը։');
      }
      return response.json();
    }

    if (operation === 'context') {
      return { origin, contextPath, project };
    }
    if (origin !== input.origin || contextPath !== input.contextPath) {
      throw new Error('Jira-ի սկզբնական ներդիրը փոխվել է։ Բացիր ընդլայնումը նորից Jira-ի էջից։');
    }

    const route = 'issue/' + encodeURIComponent(input.key);
    const [issue, available] = await Promise.all([
      request(route + '?fields=status'),
      request(route + '/transitions')
    ]);
    const status = issue.fields.status.name;
    const transitions = available.transitions.filter((item) => item.to?.name)
      .map((item) => ({ id: item.id, name: item.name, status: item.to.name }));
    if (operation === 'inspect') return { status, transitions };

    if (status === input.transition.status) return { skipped: true };
    if (!transitions.some((item) => item.id === input.transition.id && item.status === input.transition.status)) {
      throw new Error('Ընտրված անցումն այլևս հասանելի չէ։ Կրկին բեռնիր ստատուսները։');
    }
    await request(route + '/transitions', {
      method: 'POST',
      body: JSON.stringify({ transition: { id: input.transition.id } })
    });
    return { updated: true };
  } catch (error) {
    return { error: error.message };
  }
}

async function run(operation, input) {
  const [execution] = await chrome.scripting.executeScript({
    target: { tabId },
    func: jira,
    args: [operation, input]
  });
  const result = execution?.result;
  if (!result) throw new Error('Jira-ի ներդիրից պատասխան չստացվեց։');
  if (result.error) throw new Error(result.error);
  return result;
}

function parseKeys(value, project) {
  const tokens = value.toUpperCase().split(/[\s,;]+/).filter(Boolean);
  if (!tokens.length) throw new Error('Մուտքագրիր առնվազն մեկ թասկի համար։');
  return [...new Set(tokens.map((token) => {
    if (/^[A-Z][A-Z0-9_]*-\d+$/.test(token)) return token;
    if (/^\d+$/.test(token) && project) return project + '-' + token;
    throw new Error('Օգտագործիր Jira-ի ամբողջական համարը (օրինակ՝ PROJ-123) · ' + token);
  }))];
}

function populateTargets() {
  const statuses = [...new Set(issues.flatMap((issue) =>
    (issue.transitions ?? []).map((transition) => transition.status)
  ))].sort((a, b) => a.localeCompare(b));
  target.replaceChildren(new Option('Ընտրիր ստատուսը', ''));
  for (const status of statuses) target.add(new Option(status, status));
}

function matchingTransition(issue) {
  const matches = issue.transitions?.filter((item) => item.status === target.value);
  return matches?.length === 1 ? matches[0] : undefined;
}

function render() {
  inspect.disabled = busy || !context;
  keys.disabled = busy;
  target.disabled = busy || !previewReady || target.options.length < 2;
  apply.disabled = busy || !previewReady || !target.value || !issues.some((issue) =>
    issue.status !== target.value && matchingTransition(issue)
  );
  byId('results').replaceChildren(...issues.map((issue) => {
    const row = document.createElement('li');
    let detail = issue.result ?? issue.status ?? 'Ստուգվում է…';
    if (!issue.result && issue.status && target.value) {
      if (issue.status === target.value) {
        detail += ' · Արդեն ընտրված ստատուսում է';
      } else if (matchingTransition(issue)) {
        detail += ' → ' + target.value;
      } else {
        const count = issue.transitions.filter((item) => item.status === target.value).length;
        detail += count ? ' · Այս ստատուսին տանող մի քանի անցում կա' : ' · Այս անցումը հասանելի չէ';
      }
    }
    row.textContent = issue.key + ' · ' + detail;
    return row;
  }));
}

keys.addEventListener('input', () => {
  issues = [];
  populateTargets();
  message.textContent = '';
  render();
});
target.addEventListener('change', () => {
  message.textContent = '';
  render();
});

byId('form').addEventListener('submit', async (event) => {
  event.preventDefault();
  if (busy || !context) return;
  try {
    issues = parseKeys(keys.value, context.project).map((key) => ({ key }));
  } catch (error) {
    message.textContent = error.message;
    return;
  }
  previewReady = false;
  message.textContent = 'Jira-ից բեռնվում են հասանելի ստատուսները…';
  busy = true;
  render();
  for (const issue of issues) {
    try {
      Object.assign(issue, await run('inspect', { ...context, key: issue.key }));
    } catch (error) {
      issue.result = error.message;
    }
    render();
  }
  populateTargets();
  busy = false;
  previewReady = true;
  message.textContent = target.options.length > 1
    ? 'Ընտրիր նոր ստատուսը։'
    : 'Հասանելի անցումներ չեն գտնվել։';
  render();
});

apply.addEventListener('click', async () => {
  if (apply.disabled) return;
  const status = target.value;
  busy = true;
  let updated = 0;
  let failed = 0;
  let skipped = 0;
  message.textContent = 'Ստատուսները փոխվում են…';
  render();
  for (const issue of issues) {
    const transition = matchingTransition(issue);
    if (issue.status === status || !transition) {
      skipped++;
      if (!issue.result) {
        issue.result = issue.status === status
          ? status + ' · Արդեն ընտրված ստատուսում է'
          : issue.status + ' · Անցումը հասանելի չէ կամ միանշանակ չէ';
      }
      continue;
    }
    try {
      const result = await run('apply', { ...context, key: issue.key, transition });
      if (result.skipped) {
        skipped++;
      } else {
        updated++;
      }
      issue.status = status;
      issue.result = result.skipped ? status + ' · Արդեն ընտրված ստատուսում է' : status + ' · Փոխված է';
    } catch (error) {
      failed++;
      issue.result = error.message;
    }
    render();
  }
  previewReady = false;
  busy = false;
  message.textContent = `Փոխվեց՝ ${updated} · Բաց թողնվեց՝ ${skipped} · Սխալ՝ ${failed}`;
  render();
});

async function init() {
  populateTargets();
  try {
    context = await run('context', {});
    byId('source').textContent = context.origin + context.contextPath;
    if (context.project) {
      byId('hint').textContent += ' Կարող ես գրել միայն թվերը՝ ' + context.project + ' նախագծի համար։';
    }
  } catch {
    byId('source').textContent = 'Բացիր Jira-ի ներդիրը և գործարկիր ընդլայնումը հենց այդ ներդիրից։';
  }
  busy = false;
  render();
}

void init();
