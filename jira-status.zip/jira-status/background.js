chrome.action.onClicked.addListener(async (tab) => {
  const params = new URLSearchParams({ tab: tab.id });
  await chrome.tabs.create({
    windowId: tab.windowId,
    index: tab.index + 1,
    url: chrome.runtime.getURL('index.html?' + params)
  });
});
